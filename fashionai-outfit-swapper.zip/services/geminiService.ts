
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const MODEL_NAME = 'gemini-2.5-flash-image';

export const editOutfit = async (
  base64Image: string,
  outfitDescription: string
): Promise<string> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  // Extract base64 data from data URL
  const base64Data = base64Image.split(',')[1];
  const mimeType = base64Image.split(';')[0].split(':')[1];

  const imagePart = {
    inlineData: {
      mimeType: mimeType,
      data: base64Data,
    },
  };

  const textPart = {
    text: `Change the outfit of the person in this image to: ${outfitDescription}. Keep the person's identity, pose, face, and the background exactly as they are. Only change the clothing.`,
  };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { parts: [imagePart, textPart] },
    });

    if (!response.candidates || response.candidates.length === 0) {
      throw new Error("No candidates returned from AI");
    }

    const candidate = response.candidates[0];
    const imagePartResponse = candidate.content.parts.find(p => p.inlineData);

    if (imagePartResponse?.inlineData) {
      return `data:image/png;base64,${imagePartResponse.inlineData.data}`;
    }

    throw new Error("AI did not return a modified image.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
